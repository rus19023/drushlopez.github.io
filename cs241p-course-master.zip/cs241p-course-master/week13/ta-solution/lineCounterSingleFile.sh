echo "Running on file: $1"
wc -l $1
